# siga-homepage
Homepage para o Sistema de Informações Geográficas de Angra dos Reis

# Protótipo para a página no [Figma](https://www.figma.com/proto/XMQvtKBGQ2WKIODuu7PWNv/SIGA---Homepage?type=design&node-id=1-6&t=O9T6Qd2K512rUIVJ-1&scaling=scale-down&page-id=0%3A1&starting-point-node-id=1%3A6&mode=design)

